<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ControllerClass extends Controller
{
    public function class(){
        return view('admin.class');
    }
}
